/* Insight Advora LLP — services data.
   Single source of truth for the Services overview and every service detail page.
   Maps 1:1 to a `Service` model (title, slug, number, headline, description,
   capabilities, challenges, approach, outcomes, relatedServices, industries, faq).
   Nothing here is a claim about past work — outcomes are described as potential.
*/
window.IA_SERVICES = [
  {
    number: '01', slug: 'operational-excellence', title: 'Operational Excellence',
    headline: 'Turning Processes Into Performance.',
    short: 'Process improvement, operational efficiency, performance optimization and organizational effectiveness.',
    description: 'Helping organizations improve efficiency, strengthen processes and build systems that support consistent performance.',
    perspective: 'Efficiency work only matters when it connects to a commercial outcome. We start from how the operation actually runs \u2014 not how the process map says it should \u2014 and work back to the decisions, hand-offs and measures that determine performance.',
    flow: ['Current State', 'Diagnosis', 'Improvement', 'Optimized State'],
    capabilities: ['Process Improvement', 'Operational Diagnostics', 'Process Mapping', 'Organizational Efficiency', 'Performance Optimization', 'Continuous Improvement', 'Performance Management', 'Process Standardization', 'Operating Model Improvement', 'Transformation Support'],
    challenges: ['Processes that have grown around workarounds rather than design', 'Performance that varies by site, shift or team', 'Effort duplicated across functions with unclear ownership', 'Improvement initiatives that fade once attention moves on'],
    outcomes: ['Clearer process ownership and hand-offs', 'A defined baseline and measures that management trusts', 'Standard ways of working where standardization helps', 'A mechanism for improvement to continue internally'],
    related: ['business-growth-transformation', 'strategy-corporate-advisory'],
    industries: ['Manufacturing', 'Infrastructure', 'Consumer & Retail', 'Healthcare'],
    faq: [
      { q: 'Where does an operational excellence engagement usually start?', a: 'Normally with a short diagnostic: what the operation is expected to deliver, what it delivers today, and where the gap is created. That scopes the work before larger commitments are made.' },
      { q: 'Do you support implementation or only recommendations?', a: 'Both. Recommendations are developed with the teams who will run them, and we can stay involved through implementation and capability building.' }
    ]
  },
  {
    number: '02', slug: 'business-growth-transformation', title: 'Business Growth & Transformation',
    headline: 'Turning Ambition Into a Structured Path Forward.',
    short: 'Growth strategy, expansion planning, transformation initiatives and performance improvement.',
    description: 'Supporting organizations in identifying growth opportunities, expanding strategically and navigating transformation.',
    perspective: 'Growth and transformation fail in the same place \u2014 between the decision and the operating change it requires. We frame the opportunity, then sequence what has to change in people, process and governance for it to hold.',
    flow: ['Vision', 'Strategy', 'Execution', 'Growth'],
    capabilities: ['Business Growth Strategy', 'Strategic Planning', 'Market & Opportunity Assessment', 'Expansion Strategy', 'Business Transformation', 'Organizational Transformation', 'Change Management Support', 'Transformation Roadmaps', 'Performance Improvement', 'New Market Entry Strategy'],
    challenges: ['Ambition that is clear at board level but unclear in execution', 'Expansion decisions taken without an operating readiness view', 'Transformation programmes that stall after the design phase', 'Competing initiatives with no agreed sequence'],
    outcomes: ['A growth or transformation path with explicit sequencing', 'Investment and capability requirements made visible', 'Agreed ownership for each stage of delivery', 'Progress measures leadership can govern against'],
    related: ['operational-excellence', 'ma-corporate-transactions'],
    industries: ['Technology & Services', 'Consumer & Retail', 'Diversified Enterprises', 'Manufacturing'],
    faq: [
      { q: 'How is this different from a strategy document?', a: 'The output is a path, not a position paper \u2014 stages, dependencies, owners and decision points, described so the organization can act on it.' },
      { q: 'Can you work alongside an internal transformation team?', a: 'Yes. In most cases that is the better structure: we bring the external perspective and structure, the internal team carries the delivery.' }
    ]
  },
  {
    number: '03', slug: 'ma-corporate-transactions', title: 'M&A & Corporate Transactions',
    headline: 'Clarity Across the Transaction Lifecycle.',
    short: 'Advisory support for mergers, acquisitions, restructuring, due diligence and integration.',
    description: 'Supporting organizations through strategic transactions with structured analysis, due diligence support and integration perspectives.',
    perspective: 'Transaction value is usually created or lost in the operating detail \u2014 what was assumed in the model and what the business can actually deliver after close. We work on that gap, before and after the transaction.',
    flow: ['Strategy', 'Assess', 'Due Diligence', 'Transaction', 'Integration', 'Value Creation'],
    capabilities: ['M&A Advisory Support', 'Transaction Strategy', 'Due Diligence Support', 'Commercial Due Diligence', 'Business & Operational Due Diligence', 'Restructuring Advisory', 'Transaction Readiness', 'Integration Planning', 'Post-Merger Integration Support', 'Corporate Transaction Support'],
    challenges: ['Operating assumptions in the model that have not been tested', 'Diligence findings that never reach the integration plan', 'Integration treated as an event rather than a programme', 'Synergy expectations without an owner or a baseline'],
    outcomes: ['Operational and commercial assumptions examined independently', 'Diligence findings carried through into integration planning', 'A first-100-days view with named ownership', 'A clearer basis for post-close performance tracking'],
    related: ['business-growth-transformation', 'esg-sustainability'],
    industries: ['Manufacturing', 'Financial & Professional Services', 'Energy & Environment', 'Diversified Enterprises'],
    faq: [
      { q: 'Do you provide legal, accounting or investment banking services?', a: 'No. Insight Advora provides advisory support \u2014 business, operational and commercial perspectives on a transaction. Regulated legal, audit, tax and financial services are carried out by the appropriate licensed professionals, and we work alongside them.' },
      { q: 'At what stage should you be involved?', a: 'Earlier is more useful. Transaction readiness and operational diligence shape both the price conversation and the integration plan.' }
    ]
  },
  {
    number: '04', slug: 'ehs-advisory', title: 'EHS Advisory',
    headline: 'Building Safer, More Responsible Operations.',
    short: 'Environment, health and safety compliance, audits, training, remediation and risk management.',
    description: 'Helping organizations strengthen environment, health and safety practices through structured compliance, risk management and improvement initiatives.',
    perspective: 'EHS performance follows the operating system, not the policy document. We look at how work is planned, supervised and reviewed \u2014 which is where compliance either holds or quietly erodes.',
    flow: ['Assess', 'Comply', 'Control', 'Improve'],
    capabilities: ['EHS Compliance', 'EHS Audits', 'Environmental Compliance', 'Risk Assessment', 'Health & Safety Management', 'EHS Training', 'Incident Prevention', 'Environmental Remediation Support', 'Regulatory Compliance Support', 'EHS Management Systems', 'Safety Culture Improvement'],
    challenges: ['Compliance obligations tracked in several places at once', 'Audit findings that repeat year after year', 'Risk assessments that do not reflect current operations', 'Training that satisfies a requirement without changing behaviour'],
    outcomes: ['A consolidated view of applicable obligations', 'Audit and corrective-action cycles that close properly', 'Risk assessment tied to how work is actually done', 'Supervisory routines that reinforce safe practice'],
    related: ['esg-sustainability', 'operational-excellence'],
    industries: ['Manufacturing', 'Infrastructure', 'Energy & Environment', 'Healthcare'],
    faq: [
      { q: 'Do you certify management systems?', a: 'No. We provide advisory support to prepare, strengthen and audit systems; certification is issued by accredited certification bodies.' },
      { q: 'Can you support a specific regulatory submission?', a: 'We can provide compliance support and structure the underlying assessment work, coordinating with licensed specialists where a submission requires them.' }
    ]
  },
  {
    number: '05', slug: 'esg-sustainability', title: 'ESG & Sustainability',
    headline: 'Embedding Sustainability Into Business Thinking.',
    short: 'ESG frameworks, sustainability strategy, stakeholder engagement and corporate responsibility.',
    description: 'Helping organizations integrate environmental, social and governance considerations into strategy, operations and stakeholder engagement.',
    perspective: 'ESG becomes useful when it is an operating discipline rather than a reporting obligation \u2014 when the same data informs a decision and a disclosure.',
    flow: ['Environment', 'Social', 'Governance', 'Sustainable Value'],
    capabilities: ['ESG Strategy', 'ESG Assessment', 'Sustainability Strategy', 'Sustainability Frameworks', 'ESG Policy Development', 'Stakeholder Engagement', 'Corporate Responsibility', 'Sustainability Reporting Support', 'Environmental & Social Risk Advisory', 'ESG Governance', 'Sustainability Roadmaps'],
    challenges: ['Reporting demands arriving faster than internal data can support', 'ESG commitments without an operating plan behind them', 'Unclear governance over who owns which metric', 'Stakeholder expectations that differ by audience'],
    outcomes: ['A material-issues view specific to the business', 'Data ownership and definitions agreed internally', 'A sequenced roadmap rather than a single disclosure push', 'Governance that connects commitments to decisions'],
    related: ['ehs-advisory', 'strategy-corporate-advisory'],
    industries: ['Energy & Environment', 'Manufacturing', 'Financial & Professional Services', 'Consumer & Retail'],
    faq: [
      { q: 'Do you prepare sustainability reports?', a: 'We provide reporting support \u2014 framework selection, data structure, narrative and review. Assurance, where required, is provided by an independent assurance provider.' },
      { q: 'Is this relevant for a mid-sized business?', a: 'Often more so, because the requirements usually arrive through customers, lenders or regulators before internal capability exists.' }
    ]
  },
  {
    number: '06', slug: 'strategy-corporate-advisory', title: 'Strategy & Corporate Advisory',
    headline: 'Helping Leaders Navigate Complexity.',
    short: 'Business strategy, management consulting and strategic decision support.',
    description: 'Providing structured strategic perspectives to help organizations evaluate priorities, make informed decisions and navigate change.',
    perspective: 'Most leadership teams are not short of information. What helps is structure \u2014 the question framed properly, the options made comparable, and the trade-offs stated plainly.',
    flow: ['Question', 'Insight', 'Options', 'Decision', 'Action'],
    capabilities: ['Business Strategy', 'Corporate Strategy', 'Strategic Planning', 'Management Consulting', 'Organizational Strategy', 'Corporate Advisory', 'Decision Support', 'Business Model Review', 'Performance Strategy', 'Strategic Transformation'],
    challenges: ['Decisions delayed because the options are not comparable', 'Strategy that is understood at the top and not below it', 'Competing priorities with no explicit trade-off', 'Plans built on assumptions nobody has revisited'],
    outcomes: ['The decision framed with explicit criteria', 'Options set out with trade-offs and dependencies', 'A clear line from priority to initiative to measure', 'A basis for revisiting the decision as conditions change'],
    related: ['business-growth-transformation', 'operational-excellence'],
    industries: ['Diversified Enterprises', 'Technology & Services', 'Financial & Professional Services', 'Infrastructure'],
    faq: [
      { q: 'How long is a typical strategy engagement?', a: 'It depends on the decision. A focused decision-support piece can be short; a full strategy review with implementation planning runs longer and is usually staged.' },
      { q: 'Do you work with boards as well as management?', a: 'Yes \u2014 often the value is in presenting the same analysis to both in a form each can act on.' }
    ]
  }
];

/* Business challenges mapped to the practice that addresses them (challenge selector). */
window.IA_CHALLENGES = [
  { label: 'Inefficient processes', slug: 'operational-excellence' },
  { label: 'Need a growth strategy', slug: 'business-growth-transformation' },
  { label: 'Considering a transaction', slug: 'ma-corporate-transactions' },
  { label: 'Strengthening EHS systems', slug: 'ehs-advisory' },
  { label: 'Building an ESG framework', slug: 'esg-sustainability' },
  { label: 'Facing a strategic decision', slug: 'strategy-corporate-advisory' }
];
